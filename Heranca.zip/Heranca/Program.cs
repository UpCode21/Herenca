﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca
{
    class Program
    {
        static void Main(string[] args)
        {
            Desenvolvedor yvens = new Desenvolvedor("Yvens", "600.839.000-44");
            Diretor daniel = new Diretor("Daniel", "000.555.444-00");
           
            Console.ReadLine();
        }
    }
}
