﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca
{
    public class Desenvolvedor : Funcionario
    {
        public Desenvolvedor(string nome, string cpf) : base(nome, cpf, 25000)
        {
            Console.WriteLine("Criando um Desenvolver");
        }
    }
}
