﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca
{
    public abstract class Funcionario
    {
        public Funcionario(string nome, string cpf, double salario)
        {
            Console.WriteLine("Funcionario foi criado.");
            Nome = nome;
            CPF = cpf;
            Salario = salario;
        }

        public string Nome { get; set; }
        public string CPF { get; private set; }
        public double Salario { get; private set; }
    }
}
